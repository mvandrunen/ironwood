# Files Changed Summary (v1.16.0)

## Modified
- `src/data/regions/region1.js`
  - Ironwood Town: added Pokémon-style **path grammar** (tile=2) connecting exits ↔ center ↔ building doors.

- `src/data/regions/region2.js`
  - Ironwood Junction: added **vertical/horizontal spine** + aprons (tile=2) for clear authored flow.

- `src/engine/core.js`
  - Updated `BUILD_VERSION` to `v1.16.0-world-normalization`.
